package anfang;

//import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTextField;

//import java.awt.FlowLayout;
import java.awt.event.*;

//Selbst geschriebene Controller-Funktionalitaet: Moechte man
//Ereignisse abfangen, um darauf individuell zu reagieren,
//so muss man die zum Ereignis passende Listener-Schnittstelle
//implementieren.

public class PlusMinusController implements ActionListener {
	
	private JTextField zahl1;
	private JTextField zahl2;
	private JTextField ergebnis;
	
	public PlusMinusController (JTextField zahl1, JTextField zahl2, JTextField ergebnis) {
		this.zahl1 = zahl1;
		this.zahl2 = zahl2;
		this.ergebnis = ergebnis;
	}
	
	
	// In der Methode actionPerformed() muss nun die gewuenschte
	// Reaktion auf das Ereignis implementiert werden.
	public void actionPerformed (ActionEvent action) {
		
		if(action.getActionCommand() == "add") {
			String eingabe;
			//zahl1 auslesen und in int umwandeln
			eingabe = zahl1.getText();
			int z1 = Integer.parseInt(eingabe);
			//zahl2 auslesen und in int umwandeln
			eingabe = zahl2.getText();
			int z2 = Integer.parseInt(eingabe);
			//Zahlen addieren und im Textfeld ergebnis anzeigen
			int erg = z1 + z2;
			ergebnis.setText(String.valueOf(erg));
		}
		else if(action.getActionCommand() == "sub") {
			String eingabe;
			//zahl1 auslesen und in int umwandeln
			eingabe = zahl1.getText();
			int z1 = Integer.parseInt(eingabe);
			//zahl2 auslesen und in int umwandeln
			eingabe = zahl2.getText();
			int z2 = Integer.parseInt(eingabe);
			//Zahlen subtrahieren und im Textfeld ergebnis anzeigen
			int erg = z1 - z2;
			ergebnis.setText(String.valueOf(erg));
		}
	}
}