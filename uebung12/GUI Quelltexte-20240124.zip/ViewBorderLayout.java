package addierer;

// Swing-GUI-Komponenten befinden sich im Paket javax.swing
//import javax.swing.*;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JPanel;

import java.awt.BorderLayout;

public class ViewBorderLayout {
	
	public ViewBorderLayout() {
		// Hauptfenster erzeugen (mit Namen)
		JFrame frame = new JFrame ("Hauptfenster");
		frame.setLayout (new BorderLayout());
		//frame.setLayout(null);
		//frame.setSize (380, 280);
		frame.setLocation(1000,400);
		frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
		frame.setVisible (true);

		// Schaltflaeche erzeugen (mit Namen)
		JButton button1 = new JButton ("addiere");
		// Schaltflaeche dem Hauptfenster hinzuf�gen
		frame.add (button1, BorderLayout.WEST);

		// neue Schaltflaeche erzeugen (mit Namen)
		JButton button2 = new JButton ("subtrahiere");
		// Schaltflaeche dem Hauptfenster hinzuf�gen	
		frame.add (button2, BorderLayout.EAST);

		//***************************************
		// 1. leichtgewichtigen GUI-Container erzeugen und bef�llen.
		JPanel pane1 = new JPanel();
		
		JLabel label1 = new JLabel("Zahl 1 : ");
		//label1.setBounds(30, 120, 90, 30); 
		//label1.setLocation(30,120);
		//label1.setSize (90,30);
		pane1.add(label1);
		
		JTextField text1 = new JTextField(5);
		//label1.setBounds(80, 120, 60, 30); 
		//text1.setLocation(80,120);
		//text1.setSize (60,30);
		pane1.add (text1);
		//Panel1 zum Hauptfenster hinzuf�gen
		frame.add(pane1, BorderLayout.NORTH);
		
		//***************************************
		// 2. leichtgewichtigen GUI-Container erzeugen und bef�llen.
		JPanel pane2 = new JPanel();
		
		JLabel label2 = new JLabel("Zahl 2 : ");
		//label2.setBounds (30, 165, 90, 30); 
		//label2.setLocation(30,165);
		//label2.setSize (90,30);
		pane2.add(label2);

		JTextField text2 = new JTextField (5);
		//text2.setBounds (80, 165, 60, 30); 
		//text2.setLocation(80,165);
		//text2.setSize (60,30);
		pane2.add(text2);
		//Panel2 zum Hauptfenster hinzuf�gen
		frame.add (pane2, BorderLayout.SOUTH);
		
		//***************************************
		JPanel pane3 = new JPanel();
		
		JLabel label3 = new JLabel("Ergebnis : ");
		pane3.add(label3);
		//label3.setBounds (30, 165, 90, 30); 
		//label3.setLocation(185,115);
		//label3.setSize (90,30);

		JTextField erg = new JTextField(8);
		pane3.add(erg);
		//erg.setBounds(170, 140, 100, 30); 
		//erg.setLocation(170,140);
		//erg.setSize (100,30);
		
		frame.add(pane3, BorderLayout.CENTER);
		

		// Selbst geschriebener Controller f�r das Ereignis anmelden,
		// das beim Druecken der Schaltflaeche ausgeloest wird.
		//zwei unterschiedliche Controller:
		//button1.addActionListener(new PlusController());
		//button2.addActionListener(new MinusController());
		
		//Objekt vom Typ PlusMinusController erzeugen -> Textfelder dem Konstruktor �bergeben
		PlusMinusController ref = new PlusMinusController (text1, text2, erg);
		//CrazyPlusController ref = new CrazyPlusController(text1, text2, erg, button1); //zum Ausprobieren...
		
		//Aktionen (ausgel�st durch Klicken auf einen Button) benennen
		button1.setActionCommand("add");
		button2.setActionCommand ("sub");
		
		//Listener (Controller) meldet sich bei den Buttons an
		button1.addActionListener(ref);
		button2.addActionListener(ref);

		// Passe die Gr��e des Hauptfensters auf den Inhalt an.
		frame.pack();
	}

	
	
	public static void main (String[] args) {
		ViewBorderLayout meinView = new ViewBorderLayout();
	}
}