package addierer;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;

public class CrazyPlusController implements ActionListener {
	
	private JTextField zahl1;
	private JTextField zahl2;
	private JTextField ergebnis;
	private JButton add;
	

	private Timer timer = new Timer(2000, new ActionListener() 
	{
		public void actionPerformed(ActionEvent e) {
			ergebnis.setBackground(Color.yellow);
			ergebnis.setText("KEINE LUST...");
		}
	});

	public CrazyPlusController (JTextField zahl1, JTextField zahl2, JTextField ergebnis, JButton add) {
		this.zahl1 = zahl1;
		this.zahl2 = zahl2;
		this.ergebnis = ergebnis;
		this.add = add;
	}
	
	//@Override
	public void actionPerformed(ActionEvent ae) {
		
		String z1 = zahl1.getText();
		String z2 = zahl2.getText();
		
		add.setBackground(Color.orange);
		add.setText(z1 + " + " + z2 + " berechnen?");
		
		//
		//ergebnis.setText("KEINE LUST...");
		
		
		
		
		//mit zeitlicher Verz�gerung
		ergebnis.setBackground(Color.white);
		ergebnis.setText(" ");
		timer.start();
				
	}
}